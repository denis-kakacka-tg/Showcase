import UIKit
import RxSwift

final class ___FILEBASENAME___: BaseCoordinator<T> {
    private let rootViewController: UIViewController
    
    init(rootViewController: UIViewController) {
        self.rootViewController = rootViewController
    }
    
    override func start() -> Observable<T> {
        
    }
}

// MARK: - Private
extension ___FILEBASENAME___ {
    
}
