import UIKit

final class ___FILEBASENAME___: ContainerView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - Lifecycle
extension ___FILEBASENAME___ {
    
}

// MARK: - Private
extension ___FILEBASENAME___ {
    
}
