import Foundation
import RxSwift

protocol ___FILEBASENAME___Inputs {
    
}

protocol ___FILEBASENAME___Outputs {
    
}

protocol ___FILEBASENAME___Type {
    var inputs: ___FILEBASENAME___Inputs { get }
    var outputs: ___FILEBASENAME___Outputs { get }
}

struct ___FILEBASENAME___: ___FILEBASENAME___Type {
    var inputs: ___FILEBASENAME___Inputs { return self }
    var outputs: ___FILEBASENAME___Outputs { return self }
    
    // MARK: Inputs
    
    // MARK: Outputs
}

extension ___FILEBASENAME___: ___FILEBASENAME___Inputs, ___FILEBASENAME___Outputs { }
