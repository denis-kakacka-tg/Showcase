import UIKit
import RxSwift

final class ___FILEBASENAME___: UIViewController {
    private let disposeBag = DisposeBag()
    private let viewModel: ViewModelType
    
    init(viewModel: ViewModelType) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - Lifecycle
extension ___FILEBASENAME___ {
    override func loadView() {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        setupRx()
    }
}

// MARK: - Rx
extension ___FILEBASENAME___ {
    private func setupRx() {
        // MARK: Inputs
        
        // MARK: Outputs
    }
}

// MARK: - Public
extension ___FILEBASENAME___ {
    
}

// MARK: - Private
extension ___FILEBASENAME___ {
    
}

// MARK: - UI
extension ___FILEBASENAME___ {
    private func setupUI() {
        
    }
}
